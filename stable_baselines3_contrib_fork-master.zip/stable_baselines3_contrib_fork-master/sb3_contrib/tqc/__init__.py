from sb3_contrib.tqc.policies import CnnPolicy, MlpPolicy, MultiInputPolicy
from sb3_contrib.tqc.tqc import TQC

__all__ = ["CnnPolicy", "MlpPolicy", "MultiInputPolicy", "TQC"]
