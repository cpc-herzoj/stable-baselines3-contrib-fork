.. _wrappers:

Gym Wrappers
============

Additional `Gymnasium Wrappers <https://gymnasium.farama.org/api/wrappers/>`_ to enhance Gymnasium environments.

.. automodule:: sb3_contrib.common.wrappers


TimeFeatureWrapper
------------------

.. autoclass:: TimeFeatureWrapper
  :members:
